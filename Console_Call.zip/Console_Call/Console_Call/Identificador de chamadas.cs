﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Console_Call
{
    public class Identificador_de_chamadas
    {
        //Propriedades
        public bool Status { get; private set; } = true;
        private int id = 0; // -id : int

        //Métodos
        public void Display(int n)
        {
            if (Status)
            {
                this.id = n;
                System.Console.WriteLine($"Identificador de Chamadas: Exibindo número de chamada: {this.id}");
            }
        }
        public void Reset()
        {
            System.Console.WriteLine("Identificador de Chamadas: Reset (limpando display).");
            this.id = 0;
        }
    }
}
