﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Call
{
    public class Telefone
    {
        //Propriedades
        public bool Hook { get; private set; } = true; //true = no gancho, false = fora do gancho

        //Relações de Composição (depêndendcia forte - o telefone "cria" e é o dono dessas partições)
        private Campainha ringer = new Campainha();
        private Identificador_de_chamadas  callerId = new Identificador_de_chamadas();
        private Secretária_Eletrônica ansMachine = new Secretária_Eletrônica();

        //Relação de Agregação (conexão 0..1 com linha)
        public Linha Connection { get; set; } 

        //Construtor
        public Telefone()
        {
            System.Console.WriteLine("Telefone: Novo telefone criado.");
        }

        //Métodos
        public void OnHook()
        {
            System.Console.WriteLine("Telefone: Colocando o telefone no gancho...");
            this.Hook = true;
            Connection?.OnHook(); //Faz a notificação para a linha
        }
        public void OffHook()
        {
            System.Console.WriteLine("Telefone: Tirando o telefone do gancho...");
            this.Hook = false;
            Connection?.OffHook(); //Faz a notificação para a linha
        }
        public void Dial(int n)
        {
            System.Console.WriteLine($"Telefone: Discando o número {n}...");
            if (!this.Hook && Connection != null)
            {
                Connection.Dial(n); 
            }
            else
            {
                System.Console.WriteLine("Telefone: Não é possível discar. Verifique se o telefone está fora do gancho e conectado a uma linha.");
            }
        }
        public void SetCallertId(bool status)
        {
            System.Console.WriteLine($"Telefone: Secretária Eletrõnica {(status ? "ativada" : "desativada")}.");
            if (status)
            {
                ansMachine.Set();
            }
            else
            {
                ansMachine.Reset();
            }
        }
        public void RecordMessage()
        {
            System.Console.WriteLine("Telefone: Iniciando gravação.");
            this.ansMachine.Record();
        }

        public void PlayMessages()
        {
            System.Console.WriteLine("Telefone: Iniciando reprodução.");
            this.ansMachine.Playback();
        }
        public void SetAnsMachine (bool status)
        {
            System.Console.WriteLine($"Telefone: Secretária Eletrônica {(status ? "ativada" : "desativada")}.");
            if (status)
            {
                ansMachine.Set();
            }
            else
            {
                ansMachine.Reset();
            }

        }

    }
}
