﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Call
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // 1. Instanciar a Linha e o Telefone
            Linha linhaPrincipal = new Linha();
            Telefone meuTelefone = new Telefone();

            // 2. Conectar o Telefone à Linha
            linhaPrincipal.ConnectPhone(meuTelefone);
            System.Console.WriteLine("\n--- Conexão Estabelecida ---\n");

            // 3. Simular uma chamada de saída
            meuTelefone.OffHook(); // Tira do gancho
            meuTelefone.Dial(40028922); // Disca
            meuTelefone.OnHook(); // Coloca no gancho
            System.Console.WriteLine("\n---------------------------\n");

            // 4. Testar a Secretária Eletrônica
            meuTelefone.SetAnsMachine(true);
            meuTelefone.RecordMessage();
            meuTelefone.RecordMessage();
            meuTelefone.PlayMessages();
            System.Console.WriteLine("\n---------------------------\n");


            // 5. Finalizar
            System.Console.WriteLine("Tarefa de implementação concluída.");
        }
    }
    
}
