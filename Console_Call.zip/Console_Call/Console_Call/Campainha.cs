﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Call
{
    public class Campainha
    {
        // Propriedade 
        public bool Status { get; private set; } = true; // Ex: True = Volume Ativado

        // Métodos
        public void Camapinha()
        {
            if (Status)
            {
                System.Console.WriteLine("Campainha: Triiiiiim! (Fazendo barulho)");
            }
        }
        public void Reset()
        {
            System.Console.WriteLine("Campainha: Rest (Exemplo: desativado).");
            this.Status = false;
        }
    }

}
