﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Call
{
    public class Linha
    {
        //Propriedade que indica se a linha está ocupada
        public bool Busy { get; private set; } = false;

        //Relalçao de ligações feitas na linha
        private List<Telefone> connectPhones = new List<Telefone>();

        //Métodos que inicia uma ligação
        public void Dial(int n)
        {
            System.Console.WriteLine($"Linha: Discando o número {n}...");
            //Discagem (ex: checar busy, inicar chamada)
        }
        public void OffHook()
        {
            System.Console.WriteLine("Linha: Tirando o telefone do gancho...");
            // Busy = true se já estiver em uso
        }
        public void OnHook()
        {
            System.Console.WriteLine("Linha: Colocando o telefone no gancho...");
            this.Busy = false;
        }
        // Método para gerenciar relação de chamadas
        public void ConnectPhone(Telefone phone)
        {
            if (phone.Connection == null)
            {
                connectPhones.Add(phone);
                phone.Connection = this; //estabelecimento da conexão 
            }
        }
    }
}
