﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Console_Call
{
    public class Secretária_Eletrônica
    {

        //Propriedade
        public bool Status { get; private set; } = false; // Estado Ativada/Desativada

        // Relação de Composição (Muitas Mensagens)
        private List<Mensagem> recordedMessages = new List<Mensagem>();

       //Métodos
       public void Set()
        {
            System.Console.WriteLine("Secretária Eletrônica: Ativada. ");
            this.Status = true;
        }
        public void Reset()
        {
            System.Console.WriteLine("Secretária Eletrônica: Desativada.");
            this.Status = false;
        }
        public void Playback()
        {
            System.Console.WriteLine($"Secretária Eletrônica: Reproduzindo {recordedMessages.Count} mensagens.");
            foreach (var msg in recordedMessages)
            {
                msg.Play();
            }
        }
        public void Record()
        {
            if (Status)
            {
                System.Console.WriteLine("Secretária Eletrônica: Gravando nova mensagem...");
                // Simulação de gravação e adição da mensagem
                recordedMessages.Add(new Mensagem(new byte[] { 1, 2, 3 }));
            }
        }

    }
}
