﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Console_Call
{
    public class Mensagem
    {
        //Propriedade (simulação por byte[])
        private byte[] content;

        //Construtor
        public Mensagem(byte[] audioContent)
        {
            this.content = audioContent;
            System.Console.WriteLine("Mensagem: Nova mensagem criada.");
        }

        //Método de reprodução
        public void Play()
        {
            System.Console.WriteLine($"Mensagem: Reproduzindo stream de áudio de {content.Length} bytes. ");
            // Lógica de reprodução de áudio 
        }
    }
}
