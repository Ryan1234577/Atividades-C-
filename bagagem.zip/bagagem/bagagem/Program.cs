﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bagagem
{
    public class Program
    {
        static void Main(string[] args)
        {
            AirCia latam = new AirCia("LA999", "AWBLAT001", "LATAM Airlines");
            latam.inserir();

            Console.WriteLine("\n--- Teste Mala ---");

            //Criação de uma instância de Mala, associando à AirCia criada
            Mala malaJoao = new Mala(latam, "TAG12345", "Mala rígida, cor vermelha");
            malaJoao.inserir();

            // Teste dos métodos da Mala
            malaJoao.despachar("TAG12345"); // Deve retornar true
            malaJoao.despachar("TAG99999"); // Deve retornar false

            malaJoao.alterar("TAG12345");

            Console.WriteLine("\n--- Teste AirCia ---");

            // Teste dos métodos da AirCia
            latam.consultar("LA999");
            latam.alterar("LA999");
        }
    }
}
