﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bagagem
{
    public class AirCia
    {
        // Atributos (Propriedades)
        public string Codigo { get; set; }
        public string Awb { get; set; }
        public string Nome { get; set; }

        // Construtor 
        public AirCia(string codigo, string awb, string nome)
        {
            Codigo = codigo;
            Awb = awb; // documento de transporte aéreo
            Nome = nome;
        }

        // Método inserir()
        public void inserir()
        {
            // A lógica real de inserção (ex: salvar em um banco de dados ou lista)
            Console.WriteLine($"Companhia Aérea {Nome} ({Codigo}) inserida com sucesso.");
        }

        // Método consultar(codigo: string)
        public void consultar(string codigo)
        {
            // Consulta. Exemplo: Se o código fornecido for o desta instância, mostra os dados.
            if (this.Codigo == codigo)
            {
                Console.WriteLine($"Consulta - Cia Encontrada: {Nome}, AWB: {Awb}");
            }
            else
            {
                Console.WriteLine($"Consulta - Cia com código {codigo} não encontrada.");
            }
        }

        // Método alterar(codigo: string): bool
        public bool alterar(string codigo)
        {
            // Alteração. Retorna 'true' se alterado, 'false' caso contrário.
            if (this.Codigo == codigo)
            {
                // Simulação de alteração 
                this.Nome = "Novo Nome da " + this.Nome;
                Console.WriteLine($"Dados da Cia {codigo} alterados para {this.Nome}.");
                return true;
            }
            Console.WriteLine($"Não foi possível alterar. Cia com código {codigo} não encontrada.");
            return false;
        }
    }
}
