﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bagagem
{
    using System;

    public class Mala
    {
        // Atributos (Propriedades)
        public AirCia Cia { get; set; } // Relacionamento com a classe AirCia
        public string Tag { get; set; }
        public DateTime DataCad { get; set; }
        public string Caracteristica { get; set; }

        // Construtor
        public Mala(AirCia cia, string tag, string caracteristica)
        {
            Cia = cia;
            Tag = tag;
            Caracteristica = caracteristica;
            DataCad = DateTime.Now; // Inicializa a data de cadastro com a data atual do cadastro
        }

        // Método inserir()
        public void inserir()
        {
            Console.WriteLine($"Mala com Tag {Tag} cadastrada em {DataCad.ToShortDateString()} para a Cia: {Cia.Nome}");
        }

        // Método despachar(tag: string): bool
        public bool despachar(string tag)
        {
            // Lógica de despacho da mala, exemplo: só despacha se a tag for correta.
            if (this.Tag == tag && this.Cia != null)
            {
                Console.WriteLine($"Mala com Tag {tag} despachada com sucesso pela {Cia.Nome}.");
                return true;
            }
            Console.WriteLine($"Não foi possível despachar a mala com Tag {tag}.");
            return false;
        }

        // Método alterar(tag: string)
        public void alterar(string tag)
        {
            // Lógica de alteração.
            if (this.Tag == tag)
            {
                // Simulação de possível
                this.Caracteristica = "Característica Alterada";
                Console.WriteLine($"Mala com Tag {tag} alterada. Nova Característica: {this.Caracteristica}");
            }
            else
            {
                Console.WriteLine($"Não foi possível alterar. Mala com Tag {tag} não encontrada.");
            }
        }
    }
}
